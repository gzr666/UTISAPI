﻿

function GetTotal( UserId, YearID)
{

    if (Boolean(YearID)) {
        var serverName = location.protocol + '//' + document.location.host + "/api/Memberships";
        
        $.ajax(
            {
                
                type: "GET",
                dataType: "json",
                url: serverName +"/" + UserId + "/" + YearID,
                success: function (Total) {

                    if (Total.UkupnoUplaceno == Total.GodisnjaClanarina) {

                        $("input#iznosUplate").attr('disabled', 'disabled');
                        $("#ukupnaUplataDiv").hide();
                        $("#checkedDiv").show();
                       
                        $("#godisnja").text(Total.GodisnjaClanarina);

                    }
                    else {
                        $("#checkedDiv").hide();
                        $("#ukupnaUplataDiv").show();

                    $("input#iznosUplate").removeAttr('disabled');
                    $("#ukupnaUplata").text(Total.UkupnoUplaceno);
                    $("#preostalo").text(Total.PreostaloZaUplatu);
                    $("#godisnja").text(Total.GodisnjaClanarina);

                    }

                }



            }


            );
    }
    else { }
    
    
}

function AddUplata(Amount,userID,YearID,VrstaId,Datum) {

    if (Boolean(YearID) && Boolean(VrstaId)) {
        var serverName = location.protocol + '//' + document.location.host + "/api/Memberships";
        var uplata = {"Amount":Amount,"UserId":userID,"YearId":YearID,"VrstaId":VrstaId,"Datum":Datum}
        $.ajax(
            {

                type: "POST",
                dataType: "json",
                data:uplata,
                url: serverName,
                success: function (Total) {
                    $("#checkedDiv2").show();
                    $("#checkedDiv2").fadeOut(6000);

                    $("#iznosUplate").val("");
                    GetTotal(Total.UserId, Total.YearId);

                    
                   



                }



            }


            );
    }
    else { }


}

$(document).ready(function () {

    $("#errorDiv").hide();
    $("#checkedDiv").hide();
    $("#checkedDiv2").hide();
   
    //$("input#DatumIznajmljivanja").datepicker({ dateFormat: 'yy/mm/dd' });
    //$("input#DatumVracanja").datepicker({ dateFormat: 'yy/mm/dd' });
    //$("input#PocetakServisa").datepicker({ dateFormat: 'yy/mm/dd' });
    //$("input#KrajServisa").datepicker({ dateFormat: 'yy/mm/dd' });
    //    $("input#GodinaProizvodnje").datepicker({ dateFormat: 'yy' });
    $('select.odaberiGodinu').on('change', function () {
        $("#errorDiv").hide();
        var userId = $("input#secretUser").val();
        var YearId = $("select.odaberiGodinu option:selected").val();
        
        GetTotal(userId, YearId);


    });

    $("#AddUplata").click(function (e) {

        
        var userId = $("input#secretUser").val();
        var YearId = $("select.odaberiGodinu option:selected").val();
        var VrstaId = $("select.odaberiVrstux option:selected").val();
        var Datum = $("input#datumPlacanja").val();
       
        var amount = $("#iznosUplate").val();
       
        

        var prekoracenje = $("#preostalo").text();
       

        if (+amount > +prekoracenje) {
           
            $("#errorDiv").show();
            $("#errorSpan").text(prekoracenje);
            $("#iznosUplate").val("");
        }
        else {

            $("#errorDiv").hide();

            AddUplata(amount, userId, YearId,VrstaId,Datum);
        }

        return false;

    });


    $("input#DateJoined").datepicker({ dateFormat: 'yy/mm/dd' });
    $("input#datumPlacanja").datepicker({ dateFormat: 'yy/mm/dd' });


   


});