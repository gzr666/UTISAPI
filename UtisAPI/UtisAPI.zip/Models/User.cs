﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UtisAPI.Models
{
    public class User
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public DateTime DateJoined { get; set; }

        //navigational propeties
        public virtual ICollection<YearlyMembership> Memmberships { get; set; }
        public virtual ICollection<Dug> Dugovi { get; set; }



    }
}