﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UtisAPI.ViewModels
{
    public class Uplata
    {
        public double Amount { get; set; }
        public int UserId { get; set; }
        public int YearId { get; set; }
        public int VrstaId { get; set; }
        public DateTime Datum { get; set; }

    }
}