﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UtisAPI.ViewModels
{
    public class MembershipTotal
    {
        public double UkupnoUplaceno { get; set; }
        public double PreostaloZaUplatu { get; set; }
        public double GodisnjaClanarina { get; set; }

    }
}