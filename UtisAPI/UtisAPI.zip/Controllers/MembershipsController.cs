﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using UtisAPI.Models;
using UtisAPI.ViewModels;

namespace UtisAPI.Controllers
{
    [RoutePrefix("api/Memberships")]
    public class MembershipsController : ApiController
    {
         private UtisDb db = new UtisDb();


        // GET api/Memberships
        [Route("")]
        public IQueryable<YearlyMembership> GetMemmberships()
        {
            return db.Memmberships;
        }

        [Route("{UserID:int}/{YearID:int}")] 
        public MembershipTotal GetTotal(int UserID, int YearID)
        {
            User user = db.Users.Find(UserID);
            MembershipTotal total = new MembershipTotal();
            int ukupnaClanarina;
            int mjesecnaClanarina = 300/12;
            Year godinaClanarine = db.Years.Find(YearID);

            if (user.DateJoined.Year > godinaClanarine.BeginDate.Year)
            {
                ukupnaClanarina = 0;
            }
            else
            {

                if (user.DateJoined.Year == godinaClanarine.BeginDate.Year)
                {
                    //ukoliko je user uclanjen u istoj godini kao ona za koju se upalcuje clanarina tada moramo umanjiti ukupnu godisnju clanarinu
                    ukupnaClanarina = (12 - user.DateJoined.Month) * mjesecnaClanarina;

                }
                else
                {

                    ukupnaClanarina = 300;

                }

            }

            var ukupnaTrenutnaUplata = user.Memmberships.Where(d=>d.YearId==YearID).Sum(m => m.Amount);

            total.UkupnoUplaceno = ukupnaTrenutnaUplata;
            total.PreostaloZaUplatu = ukupnaClanarina - ukupnaTrenutnaUplata;
            total.GodisnjaClanarina = ukupnaClanarina;
            
         
            
           

            return total;
        
        }

        // GET api/Memberships/5
        [ResponseType(typeof(YearlyMembership))]
        public IHttpActionResult GetYearlyMembership(int id)
        {
            YearlyMembership yearlymembership = db.Memmberships.Find(id);
            if (yearlymembership == null)
            {
                return NotFound();
            }

            return Ok(yearlymembership);
        }

        // PUT api/Memberships/5
        //public IHttpActionResult PutYearlyMembership(int id, YearlyMembership yearlymembership)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != yearlymembership.ID)
        //    {
        //        return BadRequest();
        //    }

        //    db.Entry(yearlymembership).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!YearlyMembershipExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return StatusCode(HttpStatusCode.NoContent);
        //}

        // POST api/Memberships
        //[ResponseType(typeof(YearlyMembership))]

        [Route("")]
        [HttpPost]
        public YearlyMembership PostYearlyMembership(Uplata uplata)
        {

            if (!ModelState.IsValid)
            {
                return null;
            }
            YearlyMembership membership = new YearlyMembership();
            User user = db.Users.Find(uplata.UserId);
            Year year = db.Years.Find(uplata.YearId);
            VrstaUplate vrstaUplate = db.VrsteUplata.Find(uplata.VrstaId);


            //inicijaliziraj membership
            membership.User = user;
            membership.Year = year;
            membership.VrstaUplate = vrstaUplate;
            membership.Amount = uplata.Amount;
            membership.UserId = uplata.UserId;
            membership.YearId = uplata.YearId;
            membership.VrstaUplateID = uplata.VrstaId;
            membership.DatumUplate = uplata.Datum;


            db.Memmberships.Add(membership);
            db.SaveChanges();
            var dug = (from p in db.Dugovi
                      where p.UserID == uplata.UserId && p.YearID == uplata.YearId
                      select p).FirstOrDefault();

            //var uplate = db.Memmberships.Where(d =>d.UserId==uplata.UserId);
            //var godisnjeUplate = uplate.Where(d => d.YearId == uplata.YearId).Sum(d => d.Amount);
            dug.Amount -= uplata.Amount;
            
            db.SaveChanges();

            
            return membership;
        }

        //// DELETE api/Memberships/5
        //[ResponseType(typeof(YearlyMembership))]
        //public IHttpActionResult DeleteYearlyMembership(int id)
        //{
        //    YearlyMembership yearlymembership = db.Memmberships.Find(id);
        //    if (yearlymembership == null)
        //    {
        //        return NotFound();
        //    }

        //    db.Memmberships.Remove(yearlymembership);
        //    db.SaveChanges();

        //    return Ok(yearlymembership);
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool YearlyMembershipExists(int id)
        {
            return db.Memmberships.Count(e => e.ID == id) > 0;
        }
    }
    }

